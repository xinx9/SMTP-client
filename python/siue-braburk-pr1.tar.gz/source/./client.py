import socket
import sys
MAX = 2048
sfd = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)    
udp_host = sys.argv[1]		
udp_port = int(sys.argv[2]) 	
while True:		      
    msg = input("> ")
    sfd.sendto(bytes(msg, 'utf-8'),(udp_host,udp_port))
    data,addr = sfd.recvfrom(MAX)
    smsg = data.decode('ASCII')
    print(smsg)
    if("200 BYE" in smsg):
        sys.exit(0)