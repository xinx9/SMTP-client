to run this program you must have python 3.7 installed

to run server:
	> python3 server.py <PORT>

to run client:
	> python3 client.py <HOST_IP> <PORT>
