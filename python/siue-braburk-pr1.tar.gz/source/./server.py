from decimal import *
from _thread import *
import socket
import urllib.request
import sys
import threading 
import math

MAX = 2048
udp_host = urllib.request.urlopen('https://ident.me').read().decode('utf8')
udp_port = int(sys.argv[1])
print_lock = threading.Lock()


def help():
    return ("""200
HELO <server-hostname>
    -this is the first command used to start communication\n
HELP
    -this command can be issued anytime after HELO and will return a list of commands\n
CALC
    -this command must be issued before any calculator functions\n
POWER <x><e>
    -the POWER command request <x> raised to the <e> exponent\n
CUBE <x>
    -the CUBE command request the cubic root of <x>\n
FACT <x>
    -the FACT command request the factorial of <x>\n
BYE <server-hostname>
    -this command will close the communication with the server\n""")
def power(input):
    return pow(float(input[1]), float(input[2]))
def cuberoot(input):
    return (float(input[1]) **(1./3.))
def factorial(input):
    return math.factorial(abs(float(input[1])))

def threaded(nsfd):
    while True:
        hr     = "200 HELO " + udp_host + "(UDP)"
        ehr    = "200 You are already connected"
        br     = "200 BYE " + udp_host + "(UDP)"
        hel    = help()
        cr     = "200 CALC ready!"
        ecr    = "200 you are already in CALC"
        ans    = "250 "
        secu   = "500 "
        sepa   = "501 "
        bsc    = "503 "
        data,addr = nsfd.recvfrom(MAX)
        level0 = data.decode('ASCII')
        if("HELO" in level0):
            if(level0 == "HELO"):
                nsfd.sendto(bytes(sepa, 'utf-8'), addr)
            if(len(level0) > 4):
                htest = level0.split()
                if(len(htest)==2):
                    if(udp_host in level0):
                        nsfd.sendto(bytes(hr,'utf-8'),addr)

                        while True:
                            helo,addr = nsfd.recvfrom(MAX)
                            level1 = helo.decode('ASCII')
                            if("HELO" in level1):
                                htest = level1.split()
                                if(len(htest)==2):
                                    if(udp_host in level1):
                                        nsfd.sendto(bytes(ehr, 'utf-8'), addr)
                                    else:
                                        nsfd.sendto(bytes(sepa, 'utf-8'), addr)
                                else:
                                    nsfd.sendto(bytes(sepa, 'utf-8'), addr)
                            elif("CALC" in level1):
                                catest = level1.split()
                                if(len(catest)==1):
                                    nsfd.sendto(bytes(cr, 'utf-8'), addr)
                                    
                                    while True:
                                        calc,addr = nsfd.recvfrom(MAX)
                                        level2 = calc.decode('ASCII')
                                        if("HELO" in level2):
                                            htest = level2.split()
                                            if(len(htest)==2):
                                                if(udp_host in level2):
                                                    nsfd.sendto(bytes(ehr, 'utf-8'), addr)
                                                else:
                                                    nsfd.sendto(bytes(sepa, 'utf-8'), addr)
                                            else:
                                                nsfd.sendto(bytes(sepa, 'utf-8'), addr)
                                        elif("HELP" in level2):
                                            nsfd.sendto(bytes(hel, 'utf-8'), addr)
                                        elif("BYE" in level2):
                                            btest = level2.split()
                                            if(len(btest)==2):
                                                if(udp_host in level2):
                                                    nsfd.sendto(bytes(br, 'utf-8'), addr)
                                                    print_lock.release()
                                                    break
                                                    break
                                                    break
                                                else:
                                                    nsfd.sendto(bytes(sepa,'utf-8'), addr)
                                            else:
                                                nsfd.sendto(bytes(sepa,'utf-8'), addr)
                                        elif("POWER" in level2):
                                            ptest = level2.split()
                                            if(len(ptest)==3):
                                                pans = ans + str(power(ptest))
                                                nsfd.sendto(bytes(pans, 'utf-8'), addr)
                                            else:
                                                nsfd.sendto(bytes(sepa,'utf-8'), addr)
                                        elif("CUBE" in level2):
                                            ctest = level2.split()
                                            if(len(ctest)==2):
                                                cans = ans + str(cuberoot(ctest))
                                                nsfd.sendto(bytes(cans, 'utf-8'), addr)
                                            else:
                                                nsfd.sendto(bytes(sepa,'utf-8'), addr)
                                        elif("FACT" in level2):
                                            ftest = level2.split()
                                            if(len(ftest)==2):
                                                fans = ans + str(factorial(ftest))
                                                nsfd.sendto(bytes(fans, 'utf-8'), addr)
                                            else:
                                                nsfd.sendto(bytes(sepa,'utf-8'), addr)
                                        elif("CALC" in level2):
                                            nsfd.sendto(bytes(ecr,'utf-8'), addr)
                                        else:
                                            nsfd.sendto(bytes(secu, 'utf-8'), addr)

                                else:
                                    nsfd.sendto(bytes(sepa, 'utf-8'), addr)
                            elif("HELP" in level1):
                                hetest = level1.split()
                                if(len(hetest)==1):
                                    nsfd.sendto(bytes(hel, 'utf-8'), addr)
                                else:
                                    nsfd.sendto(bytes(sepa, 'utf-8'), addr)
                            elif("POWER" in level1):
                                pbsc = bsc + "CALC before POWER"
                                nsfd.sendto(bytes(pbsc, 'utf-8'), addr)
                            elif("CUBE" in level1):
                                cbsc = bsc + "CALC before CUBE"
                                nsfd.sendto(bytes(cbsc, 'utf-8'), addr)
                            elif("FACT" in level1):
                                fbsc = bsc + "CALC before FACT"
                                nsfd.sendto(bytes(fbsc, 'utf-8'), addr)
                            elif("BYE" in level1):
                                btest = level1.split()
                                if(len(btest)==2):
                                    if(udp_host in level1):
                                        nsfd.sendto(bytes(br, 'utf-8'), addr)
                                        print_lock.release()
                                        break
                                        break
                                    else:
                                        nsfd.sendto(bytes(sepa,'utf-8'), addr)
                                else:
                                    nsfd.sendto(bytes(sepa,'utf-8'), addr)
                            else:
                                nsfd.sendto(bytes(secu, 'utf-8'), addr)

                    else:
                        nsfd.sendto(bytes(sepa,'utf-8'), addr)
        elif("BYE" in level0):
            btest = level0.split()
            if(len(btest)==2):
                if(udp_host in level0):
                    nsfd.sendto(bytes(br, 'utf-8'), addr)
                    print_lock.release()
                    break
                else:
                    nsfd.sendto(bytes(sepa,'utf-8'), addr)
            else:
                nsfd.sendto(bytes(sepa,'utf-8'), addr)
        elif("CALC" in level0):
            cabsc = bsc + "HELO before CALC"
            nsfd.sendto(bytes(cabsc, 'utf-8'), addr)
        elif("HELP" in level0):
            hbsc = bsc + "HELO before HELP"
            nsfd.sendto(bytes(hbsc, 'utf-8'), addr)
        elif("POWER" in level0):
            pbsc = bsc + "HELO before POWER"
            nsfd.sendto(bytes(pbsc, 'utf-8'), addr)
        elif("CUBE" in level0):
            cbsc = bsc + "HELO before CUBE"
            nsfd.sendto(bytes(csc, 'utf-8'), addr)
        elif("FACT" in level0):
            fbsc = bsc + "HELO before FACT"
            nsfd.sendto(bytes(fbsc, 'utf-8'), addr)
        else:
            nsfd.sendto(bytes(secu, 'utf-8'), addr)

def main():
    sfd = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sfd.bind((udp_host,udp_port))
    while True:
        print_lock.acquire()
        start_new_thread(threaded, (sfd,))
    sfd.close()

if __name__ == '__main__': 
    main() 
